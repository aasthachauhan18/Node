let users = [
  { id: 1, name: "Aastha", email: "aastha@gmail.com" },
  { id: 2, name: "abc", email: "abc@gmail.com" }
];

let nextId = 3;

module.exports = { users, nextId };
